
package maintarea1;

import java.util.Scanner;

public class MainTarea1 {

    public static void main(String[] args) {
        Scanner Sca = new Scanner(System.in);
        Productos Pro = new Productos();
        Productos Pro1 = new Productos("1203","Atun de Agua","piezas",10,15,100);
        System.out.print("Codigo del producto: ");
        Pro.setcod_p(Sca.nextLine());
        System.out.print("Descripcion: ");
        Pro.setdesc(Sca.nextLine());
        System.out.print("Unidad de medida: ");
        Pro.setum(Sca.nextLine());
        System.out.print("Precio compra: ");
        Pro.setpc(Sca.nextInt());
        System.out.print("Precio venta: ");
        Pro.setpv(Sca.nextInt());
        System.out.print("Cantidad de productos: ");
        Pro.setcant_p(Sca.nextInt());
        Pro.mostrar();
        Pro1.mostrar();
    }
}
