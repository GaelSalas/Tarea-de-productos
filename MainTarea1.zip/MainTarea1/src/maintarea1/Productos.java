
package maintarea1;

public class Productos {
    private String cod_p,desc,um;
    private float pc,pv,cant_p;
    
    public Productos(){
    }
    
    public Productos(String cod_p, String desc, String um, float pc, float pv, float cant_p) {
        this.cod_p = cod_p;
        this.desc = desc;
        this.um = um;
        this.pc = pc;
        this.pv = pv;
        this.cant_p = cant_p;
    }

    public Productos(Productos Prod1) {
        this.cod_p = cod_p;
        this.desc = desc;
        this.um = um;
        this.pc = pc;
        this.pv = pv;
        this.cant_p = cant_p;
    }
    
    
    public void setcod_p(String cd){
        
        cod_p = cd;
    } 
    public void setdesc(String des){
        desc = des;
    }
    public void setum(String u){
        um = u;
    }
    public void setpc(float pc1){
        pc = pc1;
    } 
    public void setpv(float pv1){
        pv = pv1;
    }
    public void setcant_p(float cant){
        cant_p = cant;
    }
    public String getcod_p(){
        return cod_p;
    } 
    public String getdesc(){
        return desc;
    }
    public String getum(){
        return um;
    }
    public float getpc(){
        return pc;
    } 
    public float getpv(){
        return pv;
    }
    public float getcant_p(){
        return cant_p;
    }
    public float calcular_v(){
        return getpv()*getcant_p();
    }
    public float calcular_c(){
        return getpc()*getcant_p();
    }
    public float calcular_g(){
        return calcular_v()-calcular_c();
    }
    public void mostrar(){
        System.out.println("\n\n\t\t\tEntrada\t\t");
        System.out.print("|Codigo producto: "+getcod_p()+"\t");
        System.out.println("|Precio compra\t\t|"+getpc()+"|");
        System.out.print("|Descripción: "+getdesc()+"\t");
        System.out.println("|Precio venta\t\t|"+getpv()+"|");
        System.out.println("|-----------------------------------------------------|");
        System.out.print("|\t\t\t|");
        System.out.println("Calculo precio venta\t|"+calcular_v()+"|");
        System.out.print("|\t\t\t|");
        System.out.println("Calculo precio compra\t|"+calcular_c()+"|");
        System.out.print("|\t\t\t|");
        System.out.println("Calculo de ganancia\t|"+calcular_g()+"|");
        
    }
}
